$('.slider-principal').slick({
    dots: true,
    infinite: true,
    speed: 300,
    slidestoshow: 1,
    adaptiveHeight: true,
    autoplay: true,
    autoplaySpeed: 4000

});